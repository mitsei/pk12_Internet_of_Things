#ifndef USE_DHT
#define USE_DHT HUMIDITY || TEMPERATURE
#endif

#if USE_DHT
#if MODE == INCLUDES
#include <DHT.h>
DHT dht(4, DHT11);
/**
 * 1 = humidty, 2 = temperature, 3 = both
 */
char dhtDatatypes = 0;
int lastHumidity = -32768;
int lastTemperature = -32768;
int lastRead = 0;

void do_read_dht() {
  if (dhtDatatypes == 0) return;
  int time = millis();
  if (time < lastRead) {
    // Wraparound
    lastRead = 0;
  } else if ((time - lastRead) > 1000) {
    serviceNeedsUpdate |= 4;
  }
}
#elif MODE == READ

do_read_dht();

#endif
#endif // USE_DHT
