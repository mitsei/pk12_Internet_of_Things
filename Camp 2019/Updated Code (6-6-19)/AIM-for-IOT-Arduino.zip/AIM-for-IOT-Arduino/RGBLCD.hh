#if RGBLCD
#if MODE == INCLUDE
#include "rgb_lcd.h"
rgb_lcd lcd;
char lcd_content[33];

void do_write_lcd() {
  int c;
  c = read_byte();
  if (c == 255) {
    int r, g, b;
    r = read_byte();
    g = read_byte();
    b = read_byte();
    lcd.setRGB(r, g, b);
  } else {
    int offset = c ? 16 : 0;
    DEBUG("offset = ");
    DEBUGLN(offset);
    int i;
    memset(lcd_content + offset, ' ', 16);
    for (i = 0; i < 16; i++) {
      c = read_byte();
      if (!c || c == -1) break;
      lcd_content[offset + i] = c;
    }
    DEBUGLN("Updating LCD");
    DEBUG("Text = ");
    DEBUGLN(lcd_content + offset);
    lcd.setCursor(0, offset >> 4);
    lcd.print(lcd_content + offset);
  }
}

#elif MODE == SETUP
  lcd.begin(16, 2);
#elif MODE == LOOP
#endif  // MODE
#endif  // RGBLCD
