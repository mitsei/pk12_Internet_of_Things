#ifndef SETUP_H_
#define SETUP_H_

#define _DEBUG(...) Serial.print(__VA_ARGS__)
#define _DEBUGLN(...) Serial.println(__VA_ARGS__)

#if DEBUG
#undef DEBUG
#define DEBUG(...) _DEBUG(__VA_ARGS__)
#define DEBUGLN(...) _DEBUGLN(__VA_ARGS__)
#define WAIT ENABLED
#else
#undef DEBUG
#define DEBUG(...)
#define DEBUGLN(...)
#define WAIT DISABLED
#endif

#if DEVICE == ARDUINO_UNO || DEVICE == ARDUINO_YUN || DEVICE == BLUNO || DEVICE == ARDUINO_101
#define DIGITAL_PINS 14
#define ANALOG_PINS   6
#else
#define DIGITAL_PINS 54
#define ANALOG_PINS  15  // Arduino Mega
#endif

#endif
