#if PINS
#if MODE == INCLUDES

#define PIN_IS_ENABLED(arr, pin) (arr[((pin) >> 3)] & (1 << ((pin) & 7)))
#define PIN_ENABLE(arr, pin) (arr[((pin) >> 3)] |= (1 << ((pin) & 7)))
#define PIN_DISABLE(arr, pin) (arr[((pin) >> 3)] &= ~(1 << ((pin) & 7)))

char digitalPinEnabled[8]   = { 0, 0, 0, 0, 0, 0, 0, 0 };
#define DIGITAL_PIN_IS_ENABLED(pin) PIN_IS_ENABLED(digitalPinEnabled, pin)
#define DIGITAL_PIN_ENABLE(pin) PIN_ENABLE(digitalPinEnabled, pin)
#define DIGITAL_PIN_DISABLE(pin) PIN_DISABLE(digitalPinEnabled, pin)

char digitalPinDirection[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
#define DIGITAL_PIN_IS_READ(pin) (digitalPinDirection[(pin)>>8] & (1 << ((pin) & 7)))

unsigned char analogPinEnabled[2]    = { 0, 0 };
#define ANALOG_PIN_IS_ENABLED(pin) PIN_IS_ENABLED(analogPinEnabled, pin)
#define ANALOG_PIN_ENABLE(pin) PIN_ENABLE(analogPinEnabled, pin)
#define ANALOG_PIN_DISABLE(pin) PIN_DISABLE(analogPinEnabled, pin)

unsigned char digitalPinService[10]     = { 1, 8, 0, 0, 0, 0, 0, 0, 0, 0 };
#define SET_DIGITAL_PIN(pin, on) do {\
  int pinIndex = pin >> 8;\
  int mask = 1<<(pin & 7);\
  unsigned char old = digitalPinService[pinIndex];\
  digitalPinService[pinIndex] = on ? digitalPinService[pinIndex] | mask : digitalPinService[pinIndex] & ~mask;\
  if (digitalPinService[pinIndex] != old || forceUpdate) {\
    serviceNeedsUpdate |= 1;\
  }\
} while(0)

unsigned char analogPinService[20]   = { 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

void SET_ANALOG_PIN(unsigned char pin, unsigned int value) {
  unsigned char startBit = pin * 10;
  unsigned char startByte = (startBit >> 3) + 1;
  unsigned char bitOffset = startBit & 7;
  unsigned char oldValue = analogPinService[startByte];
  unsigned char oldValue2 = analogPinService[startByte+1];
  if (bitOffset == 0) {
    analogPinService[startByte] = (value >> 2) & 0xFF;
    analogPinService[startByte+1] = (analogPinService[startByte+1] & 0x3F) | ((value << 6) & 0xC0);
  } else if (bitOffset == 2) {
    analogPinService[startByte] = (analogPinService[startByte] & 0xC0) | ((value >> 4) & 0x3F);
    analogPinService[startByte+1] = (analogPinService[startByte+1] & 0xF) | ((value << 4) & 0xF0);
  } else if (bitOffset == 4) {
    analogPinService[startByte] = (analogPinService[startByte] & 0xF0) | ((value >> 6) & 0xF);
    analogPinService[startByte+1] = (analogPinService[startByte+1] & 3) | ((value << 2) & 0xFC);
  } else if (bitOffset == 6) {
    analogPinService[startByte] = (analogPinService[startByte] & 0xFC) | ((value >> 8) & 3);
    analogPinService[startByte+1] = value & 0xFF;
  }
  if (oldValue != analogPinService[startByte] || oldValue2 != analogPinService[startByte+1] || forceUpdate) {
    serviceNeedsUpdate |= 2;
  }
}


void do_enable_pins() {
  DEBUGLN(F("Got enable pins message"));
  boolean enabled = read_byte() > 0;
  // Digital pins
  for (int i = 0; i < 7; i++) {
    int mask = read_byte();
    digitalPinEnabled[i] = enabled ? digitalPinEnabled[i] | mask : digitalPinEnabled[i] & ~mask;
  }
  // Analog pins
  for (int i = 0; i < 2; i++) {
    int mask = read_byte();
    if (enabled) {
      analogPinEnabled[i] |= mask;
    } else {
      analogPinEnabled[i] |= mask;
    }
  }
  serviceNeedsUpdate |= 3;
}

void do_configure_pins() {
  DEBUGLN(F("Got configure pins message"));
  boolean output = read_byte() > 0;
  for (int i = 0; i < 7; i++) {
    int mask = read_byte();
    digitalPinDirection[i] = output ? digitalPinDirection[i] | mask : digitalPinDirection[i] & ~mask;
  }
  serviceNeedsUpdate |= 1;
}

void do_read_pins() {
  // Read digital pins
  for (char pin = 0; pin < DIGITAL_PINS; pin++) {
    if (DIGITAL_PIN_IS_ENABLED(pin) && DIGITAL_PIN_IS_READ(pin)) {
      SET_DIGITAL_PIN(pin, digitalRead(pin));
    }
  }
  // Read analog pins
  for (char pin = 0; pin < ANALOG_PINS; pin++) {
    if (ANALOG_PIN_IS_ENABLED(pin)) {
      SET_ANALOG_PIN(pin, analogRead(pin));
    }
  }
}

void do_write_digital();
void do_write_pwm();

void report_digital_pins() {
  write_bytes(digitalPinService, 10);
  // No more data, but send zeros to fill out the BLE packet (20 bytes total)
  for (int i = 0; i < 10; i++) {
    write_byte(0);
  }
}

void report_analog_pins() {
  write_bytes(analogPinService, 20);
}

void do_write_digital() {
  
}

void do_write_pwm() {
  
}

#elif MODE == READ

do_read_pins();

#endif
#endif
