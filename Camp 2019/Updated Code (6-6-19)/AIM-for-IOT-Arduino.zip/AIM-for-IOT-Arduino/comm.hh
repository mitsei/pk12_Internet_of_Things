#if MODE == INCLUDES
#if DEVICE == ARDUINO_UNO || DEVICE == ARDUINO_MEGA
#include <EEPROM.h>
#include "RBL_nRF8001.h"
#include "RBL_nRF8001.hpp"
#define RBL_BLE_SHIELD ENABLED
#elif DEVICE == ARDUINO_101
#include <CurieBLE.h>

BLEPeripheral blePeripheral;
BLEService appinventorService("E95D0000-251d-470a-a062-fa1922dfa9a7");
BLEUnsignedCharCharacteristic versionChar("E95D0001-251D-470A-A062-FA1922DFA9A7", BLERead);
BLEService uartService("713d0000-503e-4c75-ba94-3148f18d941e");
BLECharacteristic txChar("713d0002-503e-4c75-ba94-3148f18d941e", BLERead | BLENotify, 20);
BLECharacteristic rxChar("713d0003-503e-4c75-ba94-3148f18d941e", BLEWriteWithoutResponse, 20);

#endif
bool has_data();
int read_byte();
void write_byte(unsigned char value);
void write_bytes(const unsigned char *buffer, size_t size);
void write_int(int value);
void setup_comm();
void loop_comm();

#elif MODE == FUNCTIONS

#if RBL_BLE_SHIELD

bool has_data() {
  return ble_available();
}

int read_byte() {
  return ble_read();
}

void write_int(int value) {
  ble_write(value & 255);
  ble_write(value >> 8);
}

void setup_comm() {
#if DEBUG
  Serial.begin(115200);
#endif
  // Set device name
  ble_set_name(DEVICE_NAME);
  // Init. and start BLE library.
  ble_begin();
}

void loop_comm() {
  bool didEvents = false;
  if ( ble_connected() ) {
    if (!wasConnected) {
      DEBUG(F("Connected!"));
      wasConnected = true;
      forceUpdate = true;
    }
  } else if (wasConnected) {
    DEBUG(F("Disconnected!"));
    wasConnected = false;
  }


  if ( has_data() ) {
    while ( has_data() ) {
      int opcode = read_byte();
      if (opcode == -1) {
        break;  // no more data
      } else if (opcode < NUMOPS) {
        ops[opcode]();
      } else {
        // TODO(ewpatton): Handle error
      }
    }
  }

  read_devices();

  int i = 0;
  for (unsigned int bitmask = 1; bitmask != 0 && i < NUMWRITERS; bitmask <<= 1, i++) {
    if (serviceNeedsUpdate & bitmask) {
      writers[i]();
      ble_do_events();
      didEvents = true;
      serviceNeedsUpdate &= ~bitmask;
    }
  }
  if (!didEvents) {
    ble_do_events();
  }
  didEvents = false;
  forceUpdate = false;

  delay(50);
}

#elif DEVICE == BLUNO

bool has_data() {
  return Serial.available();
}

int read_byte() {
  return Serial.read();
}

void write_int(int value) {
  Serial.write(value & 255);
  Serial.write(value >> 8);
}

void write_byte(unsigned char value) {
  Serial.write(value);
}

void write_bytes(const unsigned char *buffer, size_t size) {
  while (size > 0) {
    Serial.write(*buffer);
    buffer++;
    size--;
  }
}

void setup_comm() {
  Serial.begin(115200);
  Serial.write("+++");
  delay(500);
  Serial.write("AT+NAME=" DEVICE_NAME);
  Serial.write("\r\n");
  delay(500);
  Serial.write("AT+EXIT\r\n");
  delay(500);
}

void loop_comm() {
  while (has_data()) {
    int opcode = read_byte();
    if (opcode == -1) {
      break;
    } else if (opcode < NUMOPS) {
      ops[opcode]();
    } else {
      // TODO(ewpatton): Handle error
    }
  }

  read_devices();

  int i = 0;
  for (unsigned int bitmask = 1; bitmask != 0 && i < NUMWRITERS; bitmask <<= 1, i++) {
    if (serviceNeedsUpdate & bitmask) {
      writers[i]();
      serviceNeedsUpdate &= ~bitmask;
    }
  }

  delay(50);
}

#elif DEVICE == ARDUINO_101

bool connected = false;
unsigned char messageIndex = 0;

bool has_data() {
  return messageIndex < rxChar.valueLength();
}

int read_byte() {
  if (messageIndex >= rxChar.valueLength()) {
    return -1;
  }
  return rxChar[messageIndex++];
}

unsigned char buffer[20];
unsigned char bufferIndex = 0;

void write_int(int value) {
  if (bufferIndex < 19) {
    buffer[bufferIndex++] = value & 0xFF;
    buffer[bufferIndex++] = value >> 8;
  }
}

void write_bytes(const unsigned char *data, size_t len) {
  for (unsigned char i = 0; bufferIndex < 20 && i < len; i++) {
    buffer[bufferIndex++] = data[i];
  }
}

void write_byte(unsigned char value) {
  if (bufferIndex < 20) {
    buffer[bufferIndex++] = value;
  }
}

void bleFlush() {
  txChar.setValue(buffer, bufferIndex);
  bufferIndex = 0;
  memset(buffer, 0, 20);
}

void receivedMessage(BLEDevice device, BLECharacteristic characteristic) {
  messageIndex = 0;
  int action = read_byte();
  if (action == -1) {
    return; // ???
  } else if (action > NUMOPS) {
    DEBUGLN(F("action ID too large for this version"));
    return;
  } else {
    DEBUG(F("Got action "));
    DEBUGLN(action);
    OP operation = ops[action];
    if (operation != NULL) {
      operation();
      DEBUGLN("Did operation");
    }
  }
}

void setup_comm() {
  Serial.begin(115200);
  DEBUGLN(F("Configuring..."));
  blePeripheral.setDeviceName(DEVICE_NAME);
  blePeripheral.setLocalName(DEVICE_NAME);
  blePeripheral.setAppearance(128);
  blePeripheral.setAdvertisedServiceUuid(appinventorService.uuid());
  blePeripheral.addAttribute(appinventorService);
  blePeripheral.addAttribute(versionChar);
  blePeripheral.addAttribute(uartService);
  blePeripheral.addAttribute(txChar);
  blePeripheral.addAttribute(rxChar);

  versionChar.setValue(2);
  rxChar.setEventHandler(BLEWritten, receivedMessage);

  blePeripheral.setConnectionInterval(0x0006, 0x0010);
  blePeripheral.begin();
  DEBUGLN(F("Device configured."));
}

unsigned int sensorsLastRead = millis();

void loop_comm() {
  BLECentral central = blePeripheral.central();
  if (central && !connected) {
    DEBUG(F("Connected to "));
    DEBUGLN(central.address());
    connected = true;
  } else if (connected && !central) {
    DEBUGLN(F("Disconnected"));
    connected = false;
  }

  if (central.connected()) {
    if (millis() - sensorsLastRead > 100) {
      read_devices();
      int i = 0;
      for (unsigned int bitmask = 1; bitmask != 0 && i < NUMWRITERS; bitmask <<= 1, i++) {
        if (serviceNeedsUpdate & bitmask) {
          writers[i]();
          serviceNeedsUpdate &= ~bitmask;
          bleFlush();
        }
      }
      sensorsLastRead = millis();
    }
  }
}

#endif

#elif MODE == SETUP
setup_comm();
#elif MODE == LOOP
loop_comm();
#endif // MODE
