#ifndef CONSTANTS_H__
#define CONSTANTS_H__

#define ENABLED 1
#define DISABLED 0

#define ARDUINO_UNO  0
#define ARDUINO_MEGA 1
#define ARDUINO_101  2
#define ARDUINO_YUN  3
#define BLUNO        4

#ifdef ARDUINO_AVR_UNO
#ifdef IS_BLUNO
#define DEVICE BLUNO
#else
#define DEVICE ARDUINO_UNO
#endif
#elif defined(ARDUINO_AVR_MEGA)
#define DEVICE ARDUINO_MEGA
#elif defined(ARDUINO_ARCH_ARC32)
#define DEVICE ARDUINO_101
#elif defined(ARDUINO_AVR_YUN)
#define DEVICE ARDUINO_YUN
#else
#warning "Unrecognized device type. Things might fail unexpectedly."
#endif

#define INCLUDES  0
#define FUNCTIONS 1
#define SETUP     2
#define READ      3
#define REPORT    4
#define WRITE     5
#define LOOP      6

typedef void (*WRITER)();
typedef void (*OP)();

#endif
